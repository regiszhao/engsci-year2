'''
ESC204 2022W Widget Lab 3IoT, Prelab
Task: Connect to a personal WiFi network.
Contents: structure for SSID and other info
'''
secrets = {
    "ssid": "MollieCottage",
    "password": "password"
}
