'''
ESC204 2022W Widget Lab 3IoT, Prelab
Task: Connect to a personal WiFi network.
'''
# Adapted from: https://learn.adafruit.com/circuitpython-on-the-arduino-nano-rp2040-connect/wifi
# SPDX-FileCopyrightText: 2019 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT
import board
import busio
from digitalio import DigitalInOut
from adafruit_esp32spi import adafruit_esp32spi
import adafruit_requests as requests
import adafruit_esp32spi.adafruit_esp32spi_socket as socket

# Get WiFi details from a secrets.py file
try:
    from secrets import secrets
except ImportError:
    print("WiFi secrets should be kept in secrets.py--please make a secrets.py file and add them there!")
    raise

print("Arduino Nano RP2040 Connect - ESP32 SPI webclient test")

# Set up SPI pins
esp32_cs = DigitalInOut(board.CS1)
esp32_ready = DigitalInOut(board.ESP_BUSY)
esp32_reset = DigitalInOut(board.ESP_RESET)

# Connect the RP2040 to the Nina W102 uBlox module's onboard ESP32 chip via SPI connections
spi = busio.SPI(board.SCK1, board.MOSI1, board.MISO1)
esp = adafruit_esp32spi.ESP_SPIcontrol(spi, esp32_cs, esp32_ready, esp32_reset)

# Check if ESP32 chip found and ready to connect and print chip details
if esp.status == adafruit_esp32spi.WL_IDLE_STATUS:
    print("ESP32 found and in idle mode")
print("Firmware vers.", esp.firmware_version)
print("MAC addr:", [hex(i) for i in esp.MAC_address])

# Print SSIDs for all discovered networks and their signal strengthss
for ap in esp.scan_networks():
    print("\t%s\t\tRSSI: %d" % (str(ap["ssid"], "utf-8"), ap["rssi"]))

# Try to connect to your WiFI network (using the SSID and password from secrets.py)
print("Connecting to AP...")
while not esp.is_connected:
    try:
        esp.connect_AP(secrets["ssid"], secrets["password"])
    except RuntimeError as e:
        print("could not connect to AP, retrying: ", e)
        continue

# If successfully connected, print IP and try a couple of web tests
print("Connected to", str(esp.ssid, "utf-8"), "\tRSSI:", esp.rssi)
print("My IP address is", esp.pretty_ip(esp.ip_address))
print("IP lookup adafruit.com: %s" % esp.pretty_ip(esp.get_host_by_name("adafruit.com")))
print("Ping google.com: %d ms" % esp.ping("google.com"))

# Set up socket (endpoint for web interfacing)
requests.set_socket(socket, esp)

# Try getting text from a website
TEXT_URL = "http://wifitest.adafruit.com/testwifi/index.html"
print("Fetching text from", TEXT_URL)
r = requests.get(TEXT_URL)
print("-" * 40)
print(r.text)
print("-" * 40)
r.close()
print("Done!")
